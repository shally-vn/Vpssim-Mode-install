<?php
define('ADMIN_USERNAME','');   // Admin Username
define('ADMIN_PASSWORD','');    // Admin Password
?>
